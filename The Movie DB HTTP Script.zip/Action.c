Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

///* Added by Async CodeGen.
//ID=Poll_0
//ScanType = Recording
//
//The following URLs are considered part of this conversation:
//	https://api.themoviedb.org/3/search/movie?query=zoot&api_key=cfe422613b250f702980a3bbf9e90716
//	https://api.themoviedb.org/3/search/movie?query=zooto&api_key=cfe422613b250f702980a3bbf9e90716
//	https://api.themoviedb.org/3/search/movie?query=zootop&api_key=cfe422613b250f702980a3bbf9e90716
//	https://api.themoviedb.org/3/search/movie?query=zootopi&api_key=cfe422613b250f702980a3bbf9e90716
//	https://api.themoviedb.org/3/search/movie?query=zootopia&api_key=cfe422613b250f702980a3bbf9e90716
//
//TODO - The following callbacks have been added to AsyncCallbacks.c.
//Add your code to the callback implementations as necessary.
//	Poll_0_RequestCB
//	Poll_0_ResponseCB
// */
//	web_reg_async_attributes("ID=Poll_0", 
//		"Pattern=Poll", 
//		"URL=https://api.themoviedb.org/3/search/movie?query=zoot&api_key=cfe422613b250f702980a3bbf9e90716", 
//		"PollIntervalMs=300", 
//		"RequestCB=Poll_0_RequestCB", 
//		"ResponseCB=Poll_0_ResponseCB", 
//		LAST);

	web_url("reactjs-tmdb-app", 
		"URL=https://skempin.github.io/reactjs-tmdb-app/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://code.ionicframework.com/ionicons/2.0.1/fonts/ionicons.eot?v=2.0.1", ENDITEM, 
		"Url=https://fonts.gstatic.com/s/lato/v13/KT3KS9Aol4WfR6Vas8kNcg.woff", ENDITEM, 
		"Url=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSols5HZxlQWyS9JY5d3_L9imbk0LiziHiyDtMZLHt_UNzoYUXs2g", ENDITEM, 
		"Url=https://www.google-analytics.com/analytics.js", ENDITEM, 
		"Url=https://fonts.gstatic.com/s/oswald/v13/HqHm7BVC_nzzTui2lzQTDT8E0i7KZn-EPnyo3HZu7kw.woff", ENDITEM, 
		"Url=https://api.themoviedb.org/3/movie/157336?&api_key={APIKEY}", ENDITEM, 
		"Url=https://image.tmdb.org/t/p/w500/nBNZadXqJSdt05SHLqgT0HuC5Gm.jpg", ENDITEM, 
		"Url=https://image.tmdb.org/t/p/original/xu9zaAevzQ5nnrsXN6JcahLnG4i.jpg", ENDITEM, 
		"Url=https://api.themoviedb.org/3/search/movie?query=zoot&api_key={APIKEY}", ENDITEM, 
		"Url=https://api.themoviedb.org/3/search/movie?query=zooto&api_key={APIKEY}", ENDITEM, 
		"Url=https://api.themoviedb.org/3/search/movie?query=zootop&api_key={APIKEY}", ENDITEM, 
		"Url=https://api.themoviedb.org/3/search/movie?query=zootopi&api_key={APIKEY}", ENDITEM, 
		"Url=https://api.themoviedb.org/3/search/movie?query=zootopia&api_key={APIKEY}", ENDITEM, 
		"Url=https://api.themoviedb.org/3/movie/269149?&api_key={APIKEY}", ENDITEM, 
		"Url=https://image.tmdb.org/t/p/w500/sM33SANp9z6rXW8Itn7NnG1GOEs.jpg", ENDITEM, 
		"Url=https://image.tmdb.org/t/p/original/mhdeE1yShHTaDbJVdWyTlzFvNkr.jpg", ENDITEM, 
		LAST);

/* Added by Async CodeGen.
ID = Poll_0
 */
	web_stop_async("ID=Poll_0", 
		LAST);

	return 0;
}