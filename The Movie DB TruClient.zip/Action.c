//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Navigate to 'https://skempin.github....actjs-tmdb-app/'", "snapshot=Action_1.inf");
	truclient_step("2", "Type Zootopia in Search Movie Title... textbox", "snapshot=Action_2.inf");
	truclient_step("3", "Click on Movie Name", "snapshot=Action_3.inf");
	truclient_step("4", "Verify Zootopia 's 'Visible Text' Contain Zootopia", "snapshot=Action_4.inf");

	return 0;
}
